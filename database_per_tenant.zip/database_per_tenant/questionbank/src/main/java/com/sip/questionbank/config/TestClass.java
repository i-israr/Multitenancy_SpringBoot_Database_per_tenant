package com.sip.questionbank.config;

import com.sip.questionbank.data.Category;
import com.sip.questionbank.service.QuestionBankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class TestClass {
    @Autowired
    private QuestionBankService questionBankService;

    @GetMapping("/category1")
    public List<Category> showAllCategories1() {

        List<Category> ct = new ArrayList<>();
        ct =  questionBankService.fetchAllCategories();
        return ct;
    }
}
