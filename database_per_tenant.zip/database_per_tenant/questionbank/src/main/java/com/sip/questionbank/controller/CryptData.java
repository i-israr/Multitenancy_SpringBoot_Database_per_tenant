package com.sip.questionbank.controller;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;

public class CryptData {


    private static final Key SECRET_KEY = generateAESSecretKey();
    //static String TOKEN_ENCRYPTION_KEY = "znL0Fe8KzcNfDw6f";
    private static final String ALGORITHM = "AES";
    public static String encryptToken(String text) {
        try {
            Cipher rsa = Cipher.getInstance(ALGORITHM);
            rsa.init(Cipher.ENCRYPT_MODE, SECRET_KEY);
            return Base64.getEncoder().encodeToString(rsa.doFinal(text.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }


    public static String decryptToken(String encodedToken) {
        try {
            Cipher rsa = Cipher.getInstance(ALGORITHM);
            rsa.init(Cipher.DECRYPT_MODE, SECRET_KEY);
            byte[] token = rsa.doFinal(Base64.getDecoder().decode(encodedToken));
            return new String(token, StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    private static Key generateAESSecretKey() {
        String TOKEN_ENCRYPTION_KEY = "znL0Fe8KzcNfDw6f";
        return new SecretKeySpec(TOKEN_ENCRYPTION_KEY.getBytes(StandardCharsets.UTF_8), ALGORITHM);
    }
}