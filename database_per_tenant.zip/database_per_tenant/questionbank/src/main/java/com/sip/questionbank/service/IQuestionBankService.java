package com.sip.questionbank.service;

import com.sip.questionbank.data.Category;
import com.sip.questionbank.data.QuestionAnswers;

import java.util.List;

public interface IQuestionBankService {
    List<Category> fetchAllCategories();
    List<QuestionAnswers>  fetchAllQuestionsAndAnswers();
    void saveCategory(Category category);
    void saveQuestion(QuestionAnswers question);
    void deleteQuestion(String questionId);
    void deleteCategory(String categoryId);
    Category fetchCategory(String categoryId);
    QuestionAnswers fetchQuestionAnswer(String questionId);
}
